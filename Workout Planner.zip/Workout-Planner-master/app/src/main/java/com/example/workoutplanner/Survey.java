package com.example.workoutplanner;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Survey extends AppCompatActivity {
    CheckBox cbUpper, cbLower, cbAbs, cbRunning;
    boolean BUpper = false;
    boolean BLower = false;
    boolean BAbs = false;
    boolean BRunning = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_survey);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //CheckBox UpperBody
        cbUpper = (CheckBox) findViewById(R.id.cbUpper);
        cbLower = (CheckBox) findViewById(R.id.cbLower);
        cbAbs = (CheckBox) findViewById(R.id.cbAbs);
        cbRunning = (CheckBox) findViewById(R.id.cbRunning);
    }
    public void checkone(View view){
        if (this.cbUpper.isChecked()) {
            // Checkbox is checked
            BUpper = true;
            Toast.makeText(Survey.this, "Checkbox is checked", Toast.LENGTH_SHORT).show();}
        else if(!this.cbUpper.isChecked()){
            // Checkbox is unchecked
            BUpper = false;
            Toast.makeText(Survey.this, "Checkbox is unchecked", Toast.LENGTH_SHORT).show();  }

        else if (cbLower.isChecked()) {
            // Checkbox is checked
            BLower = true;
            Toast.makeText(Survey.this, "Checkbox is checked", Toast.LENGTH_SHORT).show();}
        else if(!cbLower.isChecked()){
            // Checkbox is unchecked
            BLower = false;
            Toast.makeText(Survey.this, "Checkbox is unchecked", Toast.LENGTH_SHORT).show();  }

        else if (cbAbs.isChecked()) {
            // Checkbox is checked
            BAbs = true;
            Toast.makeText(Survey.this, "Checkbox is checked", Toast.LENGTH_SHORT).show();}
        else if(!cbAbs.isChecked()){
            // Checkbox is unchecked
            BAbs = false;
            Toast.makeText(Survey.this, "Checkbox is unchecked", Toast.LENGTH_SHORT).show();  }

        else if (cbRunning.isChecked()) {
            // Checkbox is checked
            BRunning = true;
            Toast.makeText(Survey.this, "Checkbox is checked", Toast.LENGTH_SHORT).show();}
        else if(!cbRunning.isChecked()){
            // Checkbox is unchecked
            BRunning = false;
            Toast.makeText(Survey.this, "Checkbox is unchecked", Toast.LENGTH_SHORT).show();  }
    }
}